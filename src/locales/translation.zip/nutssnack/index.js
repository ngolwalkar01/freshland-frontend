export const nutsTranslation = {
    en: {
         categoryName: 'Nuts & Snack',
         Addbtn: 'Add to Basket'
    },
    dk: {
         categoryName: 'Nødder & Snack',
         Addbtn: 'Tilføj til kurv'
    },
    fi: {
         categoryName: 'Pähkinät & Välipalat',
         Addbtn: 'Lisää koriin'
    },
    se: {
         categoryName: 'Nötter & Snacks',
         Addbtn: 'Lägg i korgen'
    },
}
