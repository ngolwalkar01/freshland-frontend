export const greenTranslation = {
    en: {
         categoryName: 'Green',
         Addbtn: 'Add to Basket'
    },
    dk: {
         categoryName: 'Grøn',
         Addbtn: 'Tilføj til kurv'
    },
    fi: {
         categoryName: 'Vihreä',
         Addbtn: 'Lisää koriin'
    },
    se: {
         categoryName: 'Grön',
         Addbtn: 'Lägg i korgen'
    },
}
