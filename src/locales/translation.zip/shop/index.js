export const shopTranslation = {
    en: {
        allGoods: "All Goods",
        ourProductComingSoon: "Our product catalog is coming soon.",
        stayTuned: "Stay tuned!",
    },
    dk: {
        allGoods: "All Goods",
        ourProductComingSoon: "Our product catalog is coming soon.",
        stayTuned: "Stay tuned!",
    },
    fi: {
        allGoods: "All Goods",
        ourProductComingSoon: "Our product catalog is coming soon.",
        stayTuned: "Stay tuned!",
    },
    se: {
        allGoods: "All Goods",
        ourProductComingSoon: "Our product catalog is coming soon.",
        stayTuned: "Stay tuned!",
    }
}