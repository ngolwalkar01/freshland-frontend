export const faqTranslation = {
    en: {
        fq: "FAQ",
        contact: "Contact us",
        info: "info@fresh.land",
        num: "53 79 07 07",
        indikaj: "Indiakaj 20, 2100 Copenhagen Ø 🇩🇰",
        faqdelivery: "Delivery",
    },
    dk: {
        fq: "dk FAQ",
        contact: "Contact us",
        info: "info@fresh.land",
        num: "53 79 07 07",
        indikaj: "Indiakaj 20, 2100 Copenhagen Ø 🇩🇰",
        faqdelivery: "Delivery",
    },
    fi: {
        fq: "fi FAQ",
        contact: "Contact us",
        info: "info@fresh.land",
        num: "53 79 07 07",
        indikaj: "Indiakaj 20, 2100 Copenhagen Ø 🇩🇰",
        faqdelivery: "Delivery",
    },
    se: {
        fq: "se FAQ",
        contact: "Contact us",
        info: "info@fresh.land",
        num: "53 79 07 07",
        indikaj: "Indiakaj 20, 2100 Copenhagen Ø 🇩🇰",
        faqdelivery: "Delivery",
    }
}