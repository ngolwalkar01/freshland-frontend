export const farmerTranslation = {
    en: {
        farmer: 'Farmers',
        weShorten: 'We shorten and digitize the food supply chain'
    },
    dk: {
        farmer: 'dk Farmers',
        weShorten: 'We shorten and digitize the food supply chain'
    },
    fi: {
        farmer: 'fi Farmers',
        weShorten: 'We shorten and digitize the food supply chain'
    },
    se: {
        farmer: 'se Farmers',
        weShorten: 'We shorten and digitize the food supply chain'
    }
}