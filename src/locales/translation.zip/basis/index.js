export const basisTranslation = {
    en: {
         categoryName: 'Basis',
         Addbtn: 'Add to Basket'
    },
    dk: {
         categoryName: 'Basis',
         Addbtn: 'Tilføj til kurv'
    },
    fi: {
         categoryName: 'Perustarvikkeet',
         Addbtn: 'Lisää koriin'
    },
    se: {
         categoryName: 'Basvaror',
         Addbtn: 'Lägg i korgen'
    },
}
