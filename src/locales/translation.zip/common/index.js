export const commonTranslation = {
    en: {
        disruptTheFoodIndustry: 'Disrupt the food industry',
        seeAllProducts: 'See All Products',
        add: 'ADD',
        save: 'Save',
        addToBasket: 'Add to Basket',
        firstName: "First Name",
    },
    dk: {
        disruptTheFoodIndustry: 'Disrupt the food industry',
        seeAllProducts: 'See All Products',
        add: 'ADD',
        save: 'Save',
        addToBasket: 'Add to Basket',
        firstName: "First Name",
    },
    fi: {
        disruptTheFoodIndustry: 'Disrupt the food industry',
        seeAllProducts: 'See All Products',
        add: 'ADD',
        save: 'Save',
        addToBasket: 'Add to Basket',
        firstName: "First Name",
    },
    se: {
        disruptTheFoodIndustry: 'Disrupt the food industry',
        seeAllProducts: 'See All Products',
        add: 'ADD',
        save: 'Save',
        addToBasket: 'Add to Basket',
        firstName: "First Name",
    }
}