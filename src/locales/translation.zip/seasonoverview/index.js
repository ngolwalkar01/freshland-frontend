export const seasonTranslation = {
    en: {
        seas: 'Season Overview',
        europ: "The European Avocado Season",
        get: "Get delicious benefits as a VIP",
        youLike: "Would you like to have a front pocket and be the very first to know when the season",
        first: "s first harvest of our fruit and vegetables is ready?",
        click: "Click the button below and register as a VIP.",
        getvip: "Get on the VIP List",
    },
    dk: {
        seas: 'dk Season Overview',
        europ: "The European Avocado Season",
        get: "Get delicious benefits as a VIP",
        youLike: "Would you like to have a front pocket and be the very first to know when the season",
        first: "s first harvest of our fruit and vegetables is ready?",
        click: "Click the button below and register as a VIP.",
        getvip: "Get on the VIP List",
    },
    fi: {
        seas: 'fi Season Overview',
        europ: "The European Avocado Season",
        get: "Get delicious benefits as a VIP",
        youLike: "Would you like to have a front pocket and be the very first to know when the season",
        first: "s first harvest of our fruit and vegetables is ready?",
        click: "Click the button below and register as a VIP.",
        getvip: "Get on the VIP List",
    },
    se: {
        seas: 'se Season Overview',
        europ: "The European Avocado Season",
        get: "Get delicious benefits as a VIP",
        youLike: "Would you like to have a front pocket and be the very first to know when the season",
        first: "s first harvest of our fruit and vegetables is ready?",
        click: "Click the button below and register as a VIP.",
        getvip: "Get on the VIP List",
    }
}